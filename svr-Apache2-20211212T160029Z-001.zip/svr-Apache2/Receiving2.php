<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta name="description"
	content="A blank HTML document for testing purposes.">
<meta name="author" content="Six Revisions">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="http://sixrevisions.com/favicon.ico"
	type="image/x-icon" />
</head>
<body>
  
<?php
include ("sql_con.php");
// Buffer larger content areas like the main page content
ob_start();
?>

<!-- Insert a Search Box and Selection List -->

<form action='Receiving2.php' method='post'>
<?php 
if(isset($_POST['ScannedSKU'])) {
	ECHO "Item Search: <input type='text' id='ScannedSKU' name='ScannedSKU' value='" . $_POST['ScannedSKU'] . "'><input type='submit' name='ScannedSKUSubmit' />";
}
else {
	ECHO "Item Search: <input type='text' autofocus id='ScannedSKU' name='ScannedSKU'><input type='submit' name='ScannedSKUSubmit' />";
}
?></form>

<?php
$reqBasic = $conn->query("SELECT ITEMS.ID, ITEMS.DESCRIPTION, MANUFACTURERS.VENDOR_NAME AS MANUFACTURER, BINS.BIN_ID, BINS.AISLE, BINS.BAY, BINS.SHELF, BINS.BIN_SLOT AS BIN FROM ITEMS LEFT JOIN MANUFACTURERS ON MANUFACTURERS.ID = ITEMS.MANUFACTURER LEFT JOIN ITEM_BINS_LINK ON ITEMS.ID = ITEM_BINS_LINK.ITEM_SKU LEFT JOIN BINS ON BINS.BIN_ID = ITEM_BINS_LINK.BIN_ID WHERE ITEMS.ID = '" . $_POST['ScannedSKU'] . "' ORDER BY BINS.AISLE, BINS.BAY, BINS.SHELF, BINS.BIN_SLOT;");
$reqBasicRow = $reqBasic->fetch();
if($reqBasicRow['ID'] != "") {
	echo "<form action='loadItem.php' method='post'>";
	echo "<table><tr><td>SKU</td><td>Manufacturer</td><td>Description</td>";
	echo "<tr><td>" . $reqBasicRow['ID'] . "</td><td>" . $reqBasicRow['MANUFACTURER'] . "</td><td>" . $reqBasicRow['DESCRIPTION'] . "</td></tr>";
	echo "</table>";
	echo "<br /><h3> Current Location </h3><br />";
	echo "<table>";
	if($reqBasicRow['BIN_ID'] == NULL) {
		echo "<tr><td><label for='AisleID'>Aisle:</lable></td><td><input type='text' autfocus id='AisleID' name='AisleID' /></td>";
		echo "</tr>";
		echo "<tr><td><label for='BayID'>Bay:</lable></td><td><input type='text' id='BayID' name='BayID' /></td>";
		echo "</tr>";
		echo "<tr><td><label for='ShelfID'>Shelf:</lable></td><td><input type='text' id='ShelfID' name='ShelfID' /></td>";
		echo "</tr>";
		echo "<tr><td><label for='BinID'>Bin:</lable></td><td><input type='text' id='BinID' name='BinID' /></td>";
		echo "</tr>";
		echo "<tr><td><label for='QtyIn'>Quantity Received:</lable></td><td><input type='text' id='QtyIn' name='QtyIn' /></td></tr>";
	}
	else {
		echo "<tr><td><label for='AisleID'>Aisle:</lable></td><td><input type='text' id='AisleID' name='AisleID' value='" . $reqBasicRow['AISLE'] . "'></td>";
		echo "</tr>";
		echo "<tr><td><label for='BayID'>Bay:</lable></td><td><input type='text' id='BayID' name='BayID' value='" . $reqBasicRow['BAY'] . "'></td>";
		echo "</tr>";
		echo "<tr><td><label for='ShelfID'>Shelf:</lable></td><td><input type='text' id='ShelfID' name='ShelfID' value='" . $reqBasicRow['SHELF'] . "'></td>";
		echo "</tr>";
		echo "<tr><td><label for='BinID'>Bin:</lable></td><td><input type='text' id='BinID' name='BinID' value='" . $reqBasicRow['BIN'] . "'></td>";
		echo "</tr>";
		echo "<tr><td><label for='QtyIn'>Quantity Received:</lable></td><td><input autofocus type='text' id='QtyIn' name='QtyIn'></td></tr>";
	}
	echo "</table><br />";
	echo "<input type='submit' value='Submit Item to Inventory'>";
	echo "</form>";
}
else {
	echo "<h2>Item Not Found</h2><br/><h3>Please enter the item details below</h3><br/>";
	echo "<form action='createItem.php' method='post'>";

	echo "<table><tr><td><label for='ScannedSKU'>Item SKU:</td><td><input type='text' id='ScannedSKU' name='ScannedSKU' value='" . $_POST['ScannedSKU'] . "'></td>";
	echo "<tr><td><label for='ItemDescription'>Description of Item</td><td><input type='text' id='ItemDescription' name='ItemDescription' autofocus></td>";

	# Getting Fancy with our drop down lists
	$ddl = $conn->query("SELECT DELIVERY_UNIT FROM UNITS;");
	$ddl->execute();
	$ddl_units = $ddl->fetchall();
	echo "<tr><td><label for='PackageUnit'>Package Unit</td><td><select name='PackageUnit' id='PackageUnit'>";
	foreach($ddl_units as $row): 
		echo "<option>" . $row["DELIVERY_UNIT"] . "</option>";
	endforeach;
	echo "</td>";

	echo "<tr><td><label for='UnitCost'>Cost per Unit</td><td><input type='text' id='UnitCost' name='UnitCost' ></td>";

	# Getting Really Fancy with our Drop Down Lists
	$ddl = $conn->query("SELECT VENDOR_NAME FROM MANUFACTURERS ORDER BY VENDOR_NAME;");
	$ddl->execute();
	$ddl_units = $ddl->fetchall();
	echo "<tr><td><label for='Manufacturer'>Manufacturer</td><td><select name='Manufacturer' id='Manufacturer'>";
	foreach($ddl_units as $row): 
		echo "<option>" . $row["VENDOR_NAME"] . "</option>";
	endforeach;
	echo "<br/>If the manufacturer is not listed, please contact Materials Management to ensure they are an approved vendor.";
	echo "<tr><td><label for='AisleID'>Aisle:</lable></td><td><input type='text' autfocus id='AisleID' name='AisleID' /></td>";
	echo "</tr>";
	echo "<tr><td><label for='BayID'>Bay:</lable></td><td><input type='text' id='BayID' name='BayID' /></td>";
	echo "</tr>";
	echo "<tr><td><label for='ShelfID'>Shelf:</lable></td><td><input type='text' id='ShelfID' name='ShelfID' /></td>";
	echo "</tr>";
	echo "<tr><td><label for='BinID'>Bin:</lable></td><td><input type='text' id='BinID' name='BinID' /></td>";
	echo "</tr>";
	echo "<tr><td><label for='QtyIn'>Quantity Received:</lable></td><td><input type='text' id='QtyIn' name='QtyIn' /></td></tr>";
	echo "</td>";
	echo "</tr></table>";
	echo "<input type='submit' value='Submit Item to Inventory'>";
	echo "</form>";
}
?>

<?php
// Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Kronos Materials Management System | Receiving";
// Apply Approved Requests
include ("master.php");
?>

</body>
</html>