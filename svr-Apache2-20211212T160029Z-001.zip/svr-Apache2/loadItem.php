<!-- SQL Connection Header File -->
<?php include ("sql_con.php"); ?>

<?php
$reqBasic = $conn->query("SELECT BINS.BIN_ID, ITEM_BINS_LINK.QTY FROM BINS LEFT JOIN ITEM_BINS_LINK ON BINS.BIN_ID = ITEM_BINS_LINK.BIN_ID WHERE BINS.AISLE = '" . $_POST['AisleID'] . "'AND BINS.BAY = '" . $_POST['BayID'] . "'AND BINS.SHELF = '" . $_POST['ShelfID'] . "'AND BINS.BIN_SLOT = '" . $_POST['BinID'] . "';");
$reqBasicRow = $reqBasic->fetch();
$QtyInVar = $reqBasicRow['QTY'];

if($QtyInVar == '0') {
    $reqBasic = $conn->query("INSERT INTO ITEM_BINS_LINK (ITEM_SKU, BIN_ID, QTY) VALUES('" . $_POST['ScannedSKU'] . "', '" . $reqBasicRow['BIN_ID'] . "', '" . $_POST['QtyIn'] . "');");
    echo "if";
}
else {
    $QtyInVar += $_POST['QtyIn'];
    $reqBasic = $conn->query("UPDATE ITEM_BINS_LINK SET QTY = '" . $QtyInVar . "' WHERE BIN_ID = '" . $reqBasicRow['BIN_ID'] . "' AND ITEM_SKU = '" . $_POST['ScannedSKU'] . "';");
    echo "else";
    }

unset($_POST['ScannedSKU']);
header("location:Receiving.php");
?>