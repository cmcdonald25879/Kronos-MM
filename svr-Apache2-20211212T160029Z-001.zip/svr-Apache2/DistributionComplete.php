<?php
include ("sql_con.php");
$reqBasic = $conn->query("UPDATE REQUISITIONS SET REQUISITIONS.STATUS = '4' WHERE REQUISITIONS.ID = '" . $_GET['req'] . "';");
$reqBasic = $conn->query("UPDATE REQUISITIONS SET REQUISITIONS.DATE_COMPLETED = NOW() WHERE REQUISITIONS.ID = '" . $_GET['req'] . "';");

header("location:Distribution.php");
?>