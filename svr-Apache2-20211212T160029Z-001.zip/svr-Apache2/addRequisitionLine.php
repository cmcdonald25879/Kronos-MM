<?php
include ("sql_con.php");
session_start();

// Get Bin Location
$reqBasic = $conn->query("SELECT BIN_ID FROM ITEM_BINS_LINK WHERE ITEM_SKU = '" . $_POST['itemSKU'] . "';");
$reqBasicRow = $reqBasic->fetch();
$Bin_ID = $reqBasicRow['BIN_ID'];

// Get Item Cost at moment of Order
$reqBasic = $conn->query("SELECT UNIT_COST FROM ITEMS WHERE ID = '" . $_POST['itemSKU'] . "';");
$reqBasicRow = $reqBasic->fetch();
$Unit_Cost = $reqBasicRow['UNIT_COST'];
$Line_Cost = intval($reqBasicRow['UNIT_COST']) * intval($_POST['OrderQty']);

// Write Back data to DB
$reqBasic = $conn->query("INSERT INTO REQUISITION_LINES (REQUISITION_NUMBER, ITEM_SKU, QTY, BIN_ID, UNIT_COST, LINE_COST, PICK_STAT) VALUES ('" . $_SESSION['hiddenReq'] . "', '" . $_POST['itemSKU'] . "', '" . $_POST['OrderQty'] . "', '" . $Bin_ID . "', '" . $Unit_Cost . "', '" . $Line_Cost . "', '0');");

echo $_SESSION['hiddenReq'];
echo "<br />";
echo $_POST['itemSKU'];
echo "<br />";
echo $_POST['OrderQty'];
echo "<br />";
echo $Bin_ID;
echo "<br />";
echo $Unit_Cost;
echo "<br />";
echo $Line_Cost;

#header("location:Ordering.php");
?>