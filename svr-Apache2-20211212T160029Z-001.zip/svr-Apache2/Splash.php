<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta name="description"
	content="A blank HTML document for testing purposes.">
<meta name="author" content="Six Revisions">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="http://sixrevisions.com/favicon.ico"
	type="image/x-icon" />
</head>
<body>

<?php
include ("sql_con.php");
// Buffer larger content areas like the main page content
ob_start();
?>
<center>
<img src="http://4.bp.blogspot.com/-H0Gga-M-5T8/URFWcadHOnI/AAAAAAAAAZE/4QH-_I4pjzc/s1600/060413-F-0000G-002.jpg" width=800 />
<h2>Splash Page!</h2>
</center>
<?php
// Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Kronos Materials Management System";
// Apply the template
include ("master.php");
?>

</body>
</html>