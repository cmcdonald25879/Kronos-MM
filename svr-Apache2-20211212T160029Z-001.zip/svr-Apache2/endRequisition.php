<?php
session_start();
include ("sql_con.php");

$reqBasic = $conn->query("UPDATE REQUISITIONS SET DELIVERY_DEPARTMENT = '" . $_SESSION['deptID'] . "' WHERE ID = '" . $_SESSION['hiddenReq'] . "';");

if($_GET['action'] == 0) {
    header("location:Splash.php");
}
else {
    header("location:Ordering.php");
}
unset($_SESSION['hiddenReq']);
?>