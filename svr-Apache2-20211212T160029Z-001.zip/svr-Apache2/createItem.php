<?php include ("sql_con.php"); ?>

<?php
#Pull in Variables for SQL Insert Statement
$ddl = $conn->query("SELECT ID FROM UNITS WHERE DELIVERY_UNIT = '" . $_POST['PackageUnit'] . "';");
$ddl->execute();
$ddl_units = $ddl->fetch();
$PackageID = $ddl_units['ID'];

$ddl = $conn->query("SELECT ID AS MAN_ID FROM MANUFACTURERS ORDER BY '" . $_POST['Manufacturer'] . "';");
$ddl->execute();
$ddl_units = $ddl->fetch();
$ManufactureID = $ddl_units['MAN_ID'];

# Insert Item into ITEMS Table
$reqBasic = $conn->query("INSERT INTO ITEMS SET ITEMS.ID = '". $_POST['ScannedSKU'] . "', ITEMS.DESCRIPTION = '" . $_POST['ItemDescription'] . "', PACKAGE = '" . $PackageID . "', UNIT_COST = '" . $_POST['UnitCost'] . "', MANUFACTURER = '" . $ManufactureID . "';");

# Add Item to Inventory
$reqBasic = $conn->query("SELECT BINS.BIN_ID, ITEM_BINS_LINK.QTY FROM BINS LEFT JOIN ITEM_BINS_LINK ON BINS.BIN_ID = ITEM_BINS_LINK.BIN_ID WHERE BINS.AISLE = '" . $_POST['AisleID'] . "'AND BINS.BAY = '" . $_POST['BayID'] . "'AND BINS.SHELF = '" . $_POST['ShelfID'] . "'AND BINS.BIN_SLOT = '" . $_POST['BinID'] . "';");
$reqBasicRow = $reqBasic->fetch();
$reqBasic = $conn->query("INSERT INTO ITEM_BINS_LINK (ITEM_SKU, BIN_ID, QTY) VALUES('" . $_POST['ScannedSKU'] . "', '" . $reqBasicRow['BIN_ID'] . "', '" . $_POST['QtyIn'] . "');");


# Clean Up and get ready for the next run
unset($_POST['ScannedSKU']);
header("location:Receiving.php");
?>