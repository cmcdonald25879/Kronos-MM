<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta name="description"
	content="A blank HTML document for testing purposes.">
<meta name="author" content="Six Revisions">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="http://sixrevisions.com/favicon.ico"
	type="image/x-icon" />
</head>
<body>
  
<?php
include ("sql_con.php");
// Buffer larger content areas like the main page content
ob_start();
session_start();
?>

<?php

// Create a new Requisition Number if one has not already been assigned
if(!isset($_SESSION['hiddenReq'])) {
    $reqBasic = $conn->query("SELECT MAX(REQUISITIONS.ID) AS ID FROM REQUISITIONS;");
    $reqBasicRow = $reqBasic->fetch();
    $hiddenReq = ($reqBasicRow['ID'] + 1);
    $_SESSION['hiddenReq'] = $hiddenReq;
    echo $hiddenReq;
    $reqBasic = $conn->query("INSERT INTO REQUISITIONS (ID, REQUESTING_USER, DATE_ENTERED, STATUS) VALUES('" . $hiddenReq . "', '" . $_COOKIE['userid'] . "', NOW(), 1);");
}
else{
    $hiddenReq = $_SESSION['hiddenReq'];
    echo $hiddenReq;
}

// Order details form
echo "<form action='Ordering.php' method='post'>";
echo "<input type='hidden' id='hiddenReq' name='hiddenReq' value='" . $hiddenReq . "'>";
echo "<table><tr>";
$reqBasic = $conn->query("SELECT LAST_NAME, FIRST_NAME FROM USERS WHERE EMP_ID = '" . $_COOKIE['userid'] . "';");
$reqBasicRow = $reqBasic->fetch();
echo "<td><label for='reqUser'>Requesting User:</lable><br />" . $reqBasicRow['LAST_NAME'] . ", " . $reqBasicRow['FIRST_NAME'] . "</td>";

// Department Drop Down List
echo "<td><label for='deptID'>Delivery Department:</lable><br />";
$reqBasic = $conn->query("SELECT DEPARTMENTS.DESCRIPTION, DEPARTMENTS.DEPARTMENTS FROM USER_ORDERING_LINK LEFT JOIN DEPARTMENTS ON USER_ORDERING_LINK.DEPT_ID = DEPARTMENTS.DEPARTMENTS WHERE USER_ORDERING_LINK.USER_ID = '" . $_COOKIE['userid'] . "';");
echo "<select name=deptID>";
while($reqBasicRow = $reqBasic->fetch()) {
#    echo "<option value='" . $reqBasicRow['ID'] . "'>" . $reqBasicRow['DESCRIPTION'] . "</option>";
    echo "<option value='" . $reqBasicRow['ID'] . "'"; if ($_POST['deptID'] == $reqBasicRow['ID']) echo "selected='selected'>" . $reqBasicRow['DESCRIPTION'] . "</option>";
}
echo "</select></td>";
if(!isset($_SESSION['deptID'])) $_SESSION['deptID'] = $_POST['deptID'];

$reqBasic = $conn->query("SELECT SUM(QTY) AS REQ_QTY, SUM(LINE_COST) AS REQ_COST, COUNT(LINE_COST) AS REQ_LINES FROM REQUISITION_LINES WHERE REQUISITION_NUMBER = '" . $hiddenReq . "';");
$reqBasicRow = $reqBasic->fetch();
if($reqBasicRow['REQ_COST'] == NULL) {
    echo "<td>Requistion Total Cost<br />$0</td>";
}
else {
    echo "<td>Requistion Total Cost<br />" . round($reqBasicRow['REQ_COST'], 2) . "</td>";
}

if($reqBasicRow['REQ_QTY'] == NULL) {
    echo "<td>Requistion Total Items<br />0</td>";
}
else {
    echo "<td>Requistion Total Items<br />" . $reqBasicRow['REQ_QTY'] . "</td>";
}
echo "<td>Requistion Total Lines<br />" . $reqBasicRow['REQ_LINES'] . "</td>";
echo "</tr></table>";
echo "<br />";

// Item Search
echo "Item Search: <input type='text' autofocus id='SearchItem' name='SearchItem'><input type='submit' name='SearchItemSubmit' value='Search for Items' />";
echo "<br />";
echo "</form>";

// Requisition Line Item Display & Submission
$reqBasic = $conn->prepare("SELECT ITEMS.ID AS SKU, ITEMS.DESCRIPTION AS 'itemDescription', UNITS.DELIVERY_UNIT, ITEMS.UNIT_COST, MANUFACTURERS.VENDOR_NAME FROM ITEMS LEFT JOIN MANUFACTURERS ON ITEMS.MANUFACTURER = MANUFACTURERS.ID LEFT JOIN UNITS ON ITEMS.PACKAGE = UNITS.ID WHERE ITEMS.DESCRIPTION LIKE '%" . $_POST['SearchItem'] . "%';");
$reqBasic->bindParam(':searchQuery', $_POST['SearchItem']);
$reqBasic->execute();
echo "<table><tr><td>Vendor</td><td>Item Description</td><td>Packaging</td><td>Unit Cost</td><td>Order Quantitiy</td><td>Submit</td></tr>";
while($reqBasicRow = $reqBasic->fetch()) {
    echo "<form action='addRequisitionLine.php' method='post'><tr><td><input type='hidden' id='NewReqID' name='NewReqID' value='" . $hiddenReq . "'><input type='hidden' id='itemSKU' name='itemSKU' value='" . $reqBasicRow['SKU'] . "'>" . $reqBasicRow['VENDOR_NAME'] . "</td><td>" . $reqBasicRow['itemDescription'] . "</td><td>" . $reqBasicRow['DELIVERY_UNIT'] . "</td><td>" . $reqBasicRow['UNIT_COST'] . "</td><td><input type='text' id='OrderQty' name='OrderQty'></td><td><input type='submit' name='SubmitLine' value='Submit Line' /></td></tr></form>";
}
echo "<br /></table>";

// Show All Existing Requisition Lines for this Req Number
echo "<h2>Items in Requisition</h2>";
$reqLines = $conn->query("SELECT MANUFACTURERS.VENDOR_NAME, REQUISITION_LINES.LINE_COST, UNITS.DELIVERY_UNIT, REQUISITION_LINES.ITEM_SKU, ITEMS.DESCRIPTION, REQUISITION_LINES.QTY, REQUISITION_LINES.UNIT_COST FROM REQUISITIONS LEFT JOIN REQUISITION_LINES ON REQUISITION_LINES.REQUISITION_NUMBER = REQUISITIONS.ID LEFT JOIN ITEMS ON REQUISITION_LINES.ITEM_SKU = ITEMS.ID LEFT JOIN UNITS ON ITEMS.PACKAGE = UNITS.ID LEFT JOIN MANUFACTURERS ON ITEMS.MANUFACTURER = MANUFACTURERS.ID WHERE REQUISITIONS.ID = '" . $hiddenReq . "';");
echo "<table><tr><td>Vendor</td><td>Item Description</td><td>Packaging</td><td>Unit Cost</td><td>Order Quantity</td></tr>";
while ($reqLinesRow = $reqLines->fetch()) {
	echo "<tr><td>" . $reqLinesRow['VENDOR_NAME'] . "</td><td>" . $reqLinesRow['DESCRIPTION'] . "</td><td>" . $reqLinesRow['DELIVERY_UNIT'] . "</td><td>" . $reqLinesRow['UNIT_COST'] . "</td><td>" . $reqLinesRow['QTY'] . "</td></tr>";
}
echo "</table>";
?>

<center><table><tr><td><a href='endRequisition.php?action=0'>Finish and Exit</a></td><td><a href='endRequisition.php?action=1'>Start a new Requisition</a></td></tr></table></center>

<?php
// Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Kronos Materials Management System | Ordering";
// Apply Approved Requests
include ("master.php");
?>

</body>
</html>