<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta name="description"
	content="A blank HTML document for testing purposes.">
<meta name="author" content="Six Revisions">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="http://sixrevisions.com/favicon.ico"
	type="image/x-icon" />
</head>
<body>
  
<?php
include ("sql_con.php");
// Buffer larger content areas like the main page content
ob_start();
?>

<!-- Insert a Search Box and Selection List -->

<form action="Receiving2.php" method="post">
<?php 
if(isset($_POST['ScannedSKU'])) {
	ECHO "Item Search: <input type='text' id='ScannedSKU' name='ScannedSKU'><input type='submit' name='ScannedSKUSubmit' />";
}
else {
	ECHO "Item Search: <input type='text' autofocus id='ScannedSKU' name='ScannedSKU'><input type='submit' name='ScannedSKUSubmit' />";
}
$ScannedSKU = $_POST['ScannedSKU'];
?>
</form>
<br />

<?php
// Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Kronos Materials Management System | Receiving";
// Apply Approved Requests
include ("master.php");
?>

</body>
</html>