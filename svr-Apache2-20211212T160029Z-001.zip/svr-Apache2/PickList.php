<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta name="description"
	content="A blank HTML document for testing purposes.">
<meta name="author" content="Six Revisions">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="http://sixrevisions.com/favicon.ico"
	type="image/x-icon" />
</head>
<body>
  
<?php
include ("sql_con.php");
// Buffer larger content areas like the main page content
ob_start();
?>

<?php
$reqBasic = $conn->query("SELECT REQUISITIONS.ID AS ID, REQUISITION_LINES.ITEM_SKU, REQUISITION_LINES.QTY, BINS.AISLE, BINS.BAY, BINS.SHELF, BINS.BIN_SLOT FROM REQUISITIONS LEFT JOIN REQUISITION_LINES ON REQUISITION_LINES.REQUISITION_NUMBER = REQUISITIONS.ID LEFT JOIN ITEM_BINS_LINK ON ITEM_BINS_LINK .ITEM_SKU = REQUISITION_LINES.ITEM_SKU LEFT JOIN BINS ON BINS.BIN_ID = ITEM_BINS_LINK.BIN_ID WHERE REQUISITION_LINES.REQUISITION_NUMBER = '" . $_GET['req'] . "' AND REQUISITION_LINES.PICK_STAT = '0' ORDER BY BINS.AISLE, BINS.BAY, BINS.SHELF, BINS.BIN_SLOT;");
if ($reqBasicRow = $reqBasic->RowCount()) {
	echo "<h2>Items to Pull</h2>";
	echo "<table><tr><td>Requisition</td><td>Item SKU</td><td>Qty</td><td>Aisle</td><td>Bay</td><td>Shelf</td><td>Bin</td><tr>";
	while ($reqBasicRow = $reqBasic->fetch()) {
		echo "<tr><td>" . $_GET['req'] . "</td><td>" . $reqBasicRow['ITEM_SKU'] . "</td><td>" . $reqBasicRow['QTY'] . "</td><td>" . $reqBasicRow['AISLE'] . "</td><td>" . $reqBasicRow['BAY'] . "</td><td>" . $reqBasicRow['SHELF'] . "</td><td>" . $reqBasicRow['BIN_SLOT'] . "</td>";
		echo "<td><a href='itemPicked.php?req=" . $_GET['req'] . "&sku=" . $reqBasicRow['ITEM_SKU'] . "'>Item Pulled</a></td></tr>";
		$reqLineCounter++;
	}
	echo "</table>";

	$reqBasic = $conn->query("SELECT REQUISITIONS.ID AS ID, REQUISITION_LINES.ITEM_SKU, REQUISITION_LINES.QTY, BINS.AISLE, BINS.BAY, BINS.SHELF, BINS.BIN_SLOT FROM REQUISITIONS LEFT JOIN REQUISITION_LINES ON REQUISITION_LINES.REQUISITION_NUMBER = REQUISITIONS.ID LEFT JOIN ITEM_BINS_LINK ON ITEM_BINS_LINK .ITEM_SKU = REQUISITION_LINES.ITEM_SKU LEFT JOIN BINS ON BINS.BIN_ID = ITEM_BINS_LINK.BIN_ID WHERE REQUISITION_LINES.REQUISITION_NUMBER = '" . $_GET['req'] . "' AND REQUISITION_LINES.PICK_STAT = '1' ORDER BY BINS.AISLE, BINS.BAY, BINS.SHELF, BINS.BIN_SLOT;");
	if ($reqBasicRow = $reqBasic->RowCount()) {
		echo "<h2>Items in Order</h2>";
		echo "<table><tr><td>Requisition</td><td>Item SKU</td><td>Qty</td><tr>";
		while ($reqBasicRow = $reqBasic->fetch()) {
			echo "<tr><td>" . $_GET['req'] . "</td><td>" . $reqBasicRow['ITEM_SKU'] . "</td><td>" . $reqBasicRow['QTY'] . "</td></tr>";
			$reqLineCounter++;
		}
		echo "</table>";
	}
}

else {
	echo "<h2><a href='DistributionComplete.php?req=" . $_GET['req'] . "'>Requisition Complete</a><br>";
}
?>

<?php
// Assign all Page Specific variables
$pagemaincontent = ob_get_contents();
ob_end_clean();
$pagetitle = "Kronos Materials Management System | Requisition Picklist";
// Apply Approved Requests
include ("master.php");
?>

</body>
</html>