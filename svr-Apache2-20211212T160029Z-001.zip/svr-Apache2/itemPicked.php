<?php
include ("sql_con.php");
$reqBasic = $conn->query("UPDATE REQUISITION_LINES SET REQUISITION_LINES.PICK_STAT = '1' WHERE REQUISITION_LINES.REQUISITION_NUMBER = '" . $_GET['req'] . "' AND  REQUISITION_LINES.ITEM_SKU = '" . $_GET['sku'] . "';");

$reqBasic = $conn->query("SELECT REQUISITION_LINES.REQUISITION_NUMBER, REQUISITION_LINES.QTY AS PULL_QTY, ITEM_BINS_LINK.QTY AS BIN_QTY, ITEM_BINS_LINK.BIN_ID FROM REQUISITION_LINES LEFT JOIN ITEM_BINS_LINK ON ITEM_BINS_LINK .ITEM_SKU = REQUISITION_LINES.ITEM_SKU WHERE REQUISITION_LINES.REQUISITION_NUMBER = '" . $_GET['req'] . "' AND  REQUISITION_LINES.ITEM_SKU = '" . $_GET['sku'] . "';");
$reqBasicRow = $reqBasic->fetch();
$spare_qty = $reqBasicRow['PULL_QTY'] - $reqBasicRow['BIN_QTY'];
$spare_bin = $reqBasicRow['BIN_ID'];
if($spare_qty == 0) {
    $reqBasic = $conn->query("DELETE FROM ITEM_BINS_LINK WHERE ITEM_BINS_LINK.BIN_ID = '" . $spare_bin . "';");
}
else {
    $reqBasic = $conn->query("UPDATE ITEM_BINS_LINK SET ITEM_BINS_LINK.QTY = '" . $spare_qty . "' WHERE ITEM_BINS_LINK.BIN_ID = '" . $spare_bin . "';");
}
header("location:PickList.php?req=" . $_GET['req']);
?>